package Grupo2;

import java.awt.Image;

public class Aeropuerto {
	
	private String nombre;
	private String ciudad;
	private Mapa mapa;
	
	public Aeropuerto(String nombre,String ciudad,Mapa mapa) {
		this.setNombre(nombre);
		this.setCiudad(ciudad);
		this.mapa=mapa;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public Mapa getMapa() {
		return mapa;
	}

	public void setMapa(Mapa mapa) {
		this.mapa = mapa;
	}

}
