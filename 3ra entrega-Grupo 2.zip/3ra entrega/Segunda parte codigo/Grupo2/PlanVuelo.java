package Grupo2;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class PlanVuelo extends Plan {
	
	private Vuelo vuelo;
	
	public PlanVuelo(String origen, String destino, Calendar fechaInicial, Calendar fechaFinal, int codigoReserva, Vuelo vuelo) {
		super(origen, destino, fechaInicial, fechaFinal, codigoReserva);
		this.vuelo=vuelo;
	}

	public Vuelo getVuelo() {
		return vuelo;
	}

	public void setVuelo(Vuelo vuelo) {
		this.vuelo = vuelo;
	}
	
	public String toString() {
		return ("Numero de vuelo " + this.vuelo.getNroVuelo() +
				" \nCompania " + this.vuelo.getCompania() + 
				" \nFecha salida " + super.getFechaInicial().getTime() + 
				" \nFecha llegada " + super.getFechaLlegada().getTime() + 
				" \nAeropuerto salida " + super.getOrigen() +
				" \nAeropuerto llegada " + this.getDestino() + 
				" \nCodigo de reserva " + this.getCodigoReserva() +
				" \nEscalas: " + "  \n" + this.vuelo.toStringEscalas());
	}
	
	public PlanVuelo getCopia() {
		PlanVuelo retorno= new PlanVuelo(this.getOrigen(),this.getDestino(), super.getFechaInicial(), super.getFechaLlegada(), 
				this.getCodigoReserva(), vuelo.getCopia());
		
		return retorno;
	}
	
}
