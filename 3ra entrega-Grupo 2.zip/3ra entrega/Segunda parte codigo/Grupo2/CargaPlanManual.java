package Grupo2;

public abstract class CargaPlanManual implements CargaPlan {
	

	@Override
	public abstract boolean cargar(/*Plan plan,*/ Usuario u);

	
}
