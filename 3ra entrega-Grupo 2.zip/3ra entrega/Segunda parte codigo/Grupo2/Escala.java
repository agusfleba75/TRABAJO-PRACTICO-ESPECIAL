package Grupo2;

import java.util.Calendar;

public class Escala {
	
	private Calendar fechaInicio;
	private Calendar fechaFin;
	private Aeropuerto aeropuerto;
	
	public Escala(Calendar fechaInicio, Calendar fechaFin,Aeropuerto aeropuerto) {
		this.fechaInicio= Calendar.getInstance();
		this.setFechaInicio(fechaInicio);
		this.fechaFin=Calendar.getInstance();
		this.setFechaFin(fechaFin);
		this.aeropuerto=aeropuerto;
	}
	
	public Aeropuerto getAeropuerto() {
		return aeropuerto;
	}
	
	public void setAeropuerto(Aeropuerto aeropuerto) {
		this.aeropuerto = aeropuerto;
	}

	public int getTiempo() {
		Calendar fechaFin= this.getFechaFin();
		Calendar fechaInicio=  this.getFechaInicio();		


		return  fechaFin.get(Calendar.HOUR) - fechaInicio.get(Calendar.HOUR);
	}

	public Calendar getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(Calendar fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public Calendar getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Calendar fechaFin) {
		this.fechaFin = fechaFin;
	}
	
}
