package Grupo2;

public abstract class CargarPlanAutomatico implements CargaPlan {
	
	private Plan nuevoPlan;
	
	public CargarPlanAutomatico(Plan nuevoPlan) {
		this.nuevoPlan= nuevoPlan;
	}

	@Override
	public abstract boolean cargar(/*Plan plan,*/ Usuario u);

	public Plan getNuevoPlan() {
		return nuevoPlan;
	}

}
