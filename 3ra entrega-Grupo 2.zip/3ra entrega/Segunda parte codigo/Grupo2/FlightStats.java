package Grupo2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FlightStats {
	
	private List<PlanVuelo> planesVuelos;
	
	public FlightStats() {
		this.planesVuelos= new ArrayList<PlanVuelo>();
	}
	
	public List<PlanVuelo> getPlanesVuelos() {
		return Collections.unmodifiableList(this.planesVuelos);
	}
	
	public void addPlanVuelo(PlanVuelo plan) {
		this.planesVuelos.add(plan);
	}
	
	public PlanVuelo getVuelo(int nro) {
		
		for(PlanVuelo u: this.planesVuelos) {
			if(u.getVuelo().getNroVuelo() ==(nro)) {
				return u.getCopia();
			}
		}
		
		return null;
		
	}	
	
}
