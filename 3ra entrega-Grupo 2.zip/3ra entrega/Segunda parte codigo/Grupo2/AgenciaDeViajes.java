package Grupo2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AgenciaDeViajes {
	
	private OpcionesUsuario opcionesUsuario;
	
	public AgenciaDeViajes(OpcionesUsuario opcionesUsuario) {
		this.opcionesUsuario= opcionesUsuario;
	}
	
	public Usuario getUsuario(int dni) {
		
		for(Usuario u: opcionesUsuario.getUsuarios()) {
			if(u.getDni() ==(dni)) {
				return u;
			}
		}
		
		return null;
	}
	
	public String verEstadisticas(int dni) {
		
		Usuario u= this.getUsuario(dni);
		String retorno= "";
		if(u!= null) {
			retorno= "Los kilometros recorridos de " + u.getDni() + "son " + this.calcularKilometrosRecorridos(u) + 
					" .La cantidad de viajes realizados son " + this.cantidadDeViajesRealizados(u);
		}
		
		return retorno;
	}
	
	public int cantidadDeViajesRealizados(Usuario usuario) {
		return usuario.getAgendaDeViajes().getViajesRealizados().size();
	}
	
	public int sumarKilomentros(List<Plan> planes) {
		
		int k= 0;
		for(Plan p: planes) {
			try {
				PlanVuelo pv= (PlanVuelo) p;
				k= k + pv.getVuelo().getKilometros();
			}
			catch 
				(Exception e){
					k= k +0;
				}
		}	
		return k;
		
	}
	
	public int calcularKilometrosRecorridos(Usuario u) {
		
		List<Viaje> viajes= u.getAgendaDeViajes().getViajesRealizados();
		int k=0;
		for(Viaje v: viajes) {
			List<Plan> planes= v.getPlanes();
			k= k+ this.sumarKilomentros(planes);
		}
		
		return k;
	}
}



