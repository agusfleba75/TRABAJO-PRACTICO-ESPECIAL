package Grupo2;

public class UsuarioPremium extends Usuario {

	public UsuarioPremium(String nombre, String apellido, int dni) {
		super(nombre, apellido, dni);
	}
	
	public String recibirNotificacionChekin(String notificacion) {
		return notificacion;
	}
	
	public String recibirNotificacionCambioDeVuelo(String notificacion) {
		return notificacion;
	}
	
	public String recibirNotificacionDeCinta(String notificacion) {
		return notificacion;
	}
	
	public Mapa getMapaDeAeropuerto() {
		
		for(Plan p: this.getAgendaDeViajes().getViajeActual().getPlanes()) {
			try {
				PlanVuelo v= (PlanVuelo) p; //obtengo el aeropuerto 
				return v.getVuelo().getAeropuerto().getMapa();// obtengo el mapa del aeropuerto
			}
			catch 
				(Exception e){
					return null;
				}
		}
		return null;
	}

	
	

}
