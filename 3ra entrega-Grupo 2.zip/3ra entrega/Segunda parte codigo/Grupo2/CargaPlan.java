package Grupo2;

public interface CargaPlan {

	public abstract boolean cargar(/*Plan plan,*/ Usuario u);
}
