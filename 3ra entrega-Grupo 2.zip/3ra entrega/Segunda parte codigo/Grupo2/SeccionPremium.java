package Grupo2;

import java.util.List;
import java.util.Scanner;

public class SeccionPremium extends OpcionesUsuario{

	public SeccionPremium(FlightStats servicioExterno) {
		super(servicioExterno);
	}
	
	public String getMostradores(Viaje viajeActual) {
		return null;
	}
	
	public void notificarCinta(UsuarioPremium u) {
		//notifica al usuario cual es la cinta donde retira su equipaje
		u.recibirNotificacionDeCinta("");
	}
	
	public void notificarDondeHacerChekin() {
		
		for(Usuario u: this.getUsuarios()) {
			UsuarioPremium up= (UsuarioPremium) u;
			Viaje viajeActual= up.getAgendaDeViajes().getViajeActual();
			if(viajeActual !=null) {
				up.recibirNotificacionChekin("El chekin lo hace en los mostradores " + this.getMostradores(viajeActual));
			}
		}
	}
	
	public void notificarCambiosDeVuelo(UsuarioPremium usuarioPremium, PlanVuelo planV) {
		usuarioPremium.recibirNotificacionCambioDeVuelo("El vuelo " + planV.getCodigoReserva() + " cambio. Comunicarse con la agencia");
	}
	
	public void recorrerPlanes(List<Plan> planes, UsuarioPremium usuarioPremium) {
		
		//por cada plan 
		for(Plan p: planes) {
			try {
				PlanVuelo pv= (PlanVuelo) p;
				if(pv.hayCambios()) { // verifico si hay cambios en los planes
					this.notificarCambiosDeVuelo(usuarioPremium, pv); //si los hay, se notifican
				}
			}
			catch 
				(Exception e){
					
				}
		}
	}
	
	public void recorrerViajes(List<Viaje> viajes, UsuarioPremium usuarioPremium) {
		//por cada viaje
		for(Viaje v: viajes) {
			List<Plan> planes= v.getPlanes();
			this.recorrerPlanes(planes, usuarioPremium); // recorro sus planes
		}
	}
	
	public void verificarCambiosVuelo() {
		
		//por cada usuario premium
		for(Usuario u: this.getUsuarios()) {
			UsuarioPremium up= (UsuarioPremium) u;
			List<Viaje> viajesFuturos= up.getAgendaDeViajes().getViajesFuturos(); //obtengo sus viajes futuros
			this.recorrerViajes(viajesFuturos, up); // recorro sus viajes futuros
		}
	}
	
	public void verMapaAeropuerto() {
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Ingrese su dni ");
		int dni=sc.nextInt();
		UsuarioPremium u= (UsuarioPremium)this.getUsuario(dni);
		
		u.getMapaDeAeropuerto();
		//SE MUESTRA EL MAPA DEL AEROPUERTO DEL VIAJE ACTUAL	
	}

}
