package Grupo2;

import java.util.Calendar;
import java.util.Scanner;

public class PlanHotel extends Plan {
	
	private Hotel hotel;
	private int nroHabitacion;
	private Calendar fechaSalida;

	public PlanHotel(String origen, String destino, Calendar fechaInicial, Calendar fechaLlegada, int codigoReserva,
			Hotel hotel, int nroHabitacion, Calendar fechaSalida) {
		super(origen, destino, fechaInicial, fechaLlegada, codigoReserva/*, "tipoHotel"*/);
		this.setHotel(hotel);
		this.setNroHabitacion(nroHabitacion);
		this.setFechaSalida(fechaSalida);
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public int getNroHabitacion() {
		return nroHabitacion;
	}

	public void setNroHabitacion(int nroHabitacion) {
		this.nroHabitacion = nroHabitacion;
	}

	public Calendar getFechaSalida() {
		return fechaSalida;
	}

	public void setFechaSalida(Calendar fechaSalida) {
		this.fechaSalida = fechaSalida;
	}

	public String toString() {
		return (this.getHotel().toString() +
				" \nNumero de habitacion " + this.getNroHabitacion() + 
				" \nFecha de salida " + this.getFechaSalida());
	}
	
	public PlanHotel getCopia() {
		PlanHotel retorno= new PlanHotel(this.getOrigen(),this.getDestino(), super.getFechaInicial(), super.getFechaLlegada(), 
				this.getCodigoReserva(), this.getHotel(), this.getNroHabitacion(), this.getFechaSalida());
		
		return retorno;
	}
}
