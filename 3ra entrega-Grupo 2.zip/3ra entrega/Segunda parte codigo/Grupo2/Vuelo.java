package Grupo2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Vuelo {
	
	private String compania;
	private String clase;
	private int nroVuelo;
	private List<Escala> escalas;
	private int kilometros;
	private Aeropuerto aeropuerto;
	
	public Vuelo(String compania, String clase, int nroVuelo, int kilometros, Aeropuerto aeropuerto) {
		this.compania= compania;
		this.clase= clase;
		this.nroVuelo= nroVuelo;
		this.escalas= new ArrayList<Escala>();
		this.setKilometros(kilometros);
		this.setAeropuerto(aeropuerto);
	}

	public String getCompania() {
		return compania;
	}

	public void setCompania(String compania) {
		this.compania = compania;
	}

	public String getClase() {
		return clase;
	}

	public void setClase(String clase) {
		this.clase = clase;
	}
	
	public int getNroVuelo() {
		return nroVuelo;
	}

	public void setNroVuelo(int nroVuelo) {
		this.nroVuelo = nroVuelo;
	}
	
	public List<Escala> getEscalas() {
		return Collections.unmodifiableList(escalas);
	}

	public void addEscala(Escala escala) {
		this.escalas.add(escala);
	}
	
	public String toStringEscalas() {
		String retorno="";
		for(Escala e: this.escalas) {
			retorno= retorno + " aeropuerto " + e.getAeropuerto()+ " tiempo " +  e.getTiempo() +  " \n";
		}
		
		return retorno;
	}
	
	public Vuelo getCopia() {
		Vuelo retorno = new Vuelo(this.getCompania(), this.getClase(), this.getNroVuelo(), this.getKilometros(), this.getAeropuerto());
		
		for(Escala e: this.escalas) {
			retorno.addEscala(e);
		}
		
		return retorno;
	}

	public int getKilometros() {
		return kilometros;
	}

	public void setKilometros(int kilometros) {
		this.kilometros = kilometros;
	}

	public Aeropuerto getAeropuerto() {
		return aeropuerto;
	}

	public void setAeropuerto(Aeropuerto aeropuerto) {
		this.aeropuerto = aeropuerto;
	}

}
