package Grupo2;

import java.util.Calendar;
import java.util.Scanner;

public class CargaPlanManualViaje extends CargaPlanManual {
	
	private FlightStats servicioExterno;
	
	public CargaPlanManualViaje(FlightStats servicioExterno) {
	    this.servicioExterno=servicioExterno;
	
	}
	
	public FlightStats getServicioExterno() {
		return servicioExterno;
	}
	
	public PlanVuelo pedirNroDeVuelo() {
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Ingrese numero de vuelo");
		int nroVuelo=  sc.nextInt();
		PlanVuelo v= this.getServicioExterno().getVuelo(nroVuelo);
		//FALTA CONTEMPLAR QUE NO VENGA NULL
		return v;
	}
	
	public String pedirNombreCompania() {
		
		String compania;
		Scanner sc= new Scanner(System.in);
		System.out.println("Ingrese nombre de la compania");
		compania=  sc.nextLine();
		return compania;
	}
	
	public Calendar pedirFechaSalida() {
		
		Scanner sc= new Scanner(System.in);
		Calendar fechaInicial = null;
		System.out.println("Ingrese anio fecha salida");
		int anio= sc.nextInt();
		System.out.println("Ingrese mes fecha salida");
		int mes= sc.nextInt();
		System.out.println("Ingrese dia fecha salida");
		int dia= sc.nextInt();
		
		fechaInicial.set(anio, mes, dia);
		
		return fechaInicial;
		
	}

	public PlanVuelo pedirDatos() {
		
		PlanVuelo planV= this.pedirNroDeVuelo();
		planV.getVuelo().setCompania(this.pedirNombreCompania());
		planV.setFechaInicial(this.pedirFechaSalida());
		
		return planV;
		
	}
	
	public String pedirDescripcion() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Ingrese descripcion para su viaje");
		String desc=  sc.nextLine();
		return desc;
	}
	
	public String pedirNombreViaje() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Ingrese nombre para su viaje");
		String nombre=  sc.nextLine();
		return nombre;
	}


	@Override
	public boolean cargar(Usuario u) {
			PlanVuelo planIda;
			PlanVuelo planVuelta;
			Viaje viaje= new Viaje(this.pedirDescripcion() , this.pedirNombreViaje());
			planIda = pedirDatos();
			planVuelta= pedirDatos();
			viaje.addPlanes(planIda);
			viaje.addPlanes(planVuelta);
			viaje.setUsuario(u);
			u.getAgendaDeViajes().addViajes(viaje);
			
		return true;
	}


}
