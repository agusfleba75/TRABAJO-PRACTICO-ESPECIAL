package Grupo2;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class OpcionesUsuario {
	
	private FlightStats servicioExterno;
	private List<Usuario> usuarios;
	private List<PlanVuelo> planesVuelo;
	private List<PlanHotel> planHotel;

	public OpcionesUsuario(FlightStats servicioExterno) {
		this.usuarios= new ArrayList<Usuario>();
		this.planesVuelo=new ArrayList<PlanVuelo>();
		this.planHotel= new ArrayList<PlanHotel>();
		this.servicioExterno=servicioExterno;
	}
	
	public void cargaManual(CargaPlanManual cargaManual, Usuario u) {
		
		cargaManual.cargar(u);
	
	}
	
	public void addPlanHotel(PlanHotel p) {
		this.planHotel.add(p);
	}
	
	public List<PlanHotel> getPlanHotel(){
		return Collections.unmodifiableList(this.planHotel);
	}
	
	public List<Usuario> getUsuarios() {
		return Collections.unmodifiableList(this.usuarios);
	}

	public void setUsuario(Usuario usuario) {
		this.usuarios.add(usuario);
	}
	
	public Usuario getUsuario(int dni) {
		
		for(Usuario u: this.usuarios) {
			if(u.getDni() ==(dni)) {
				return u;
			}
		}
		
		return null;
	}
	
	public boolean esCargaAutomatica() {
		Scanner sc= new Scanner(System.in);
		String carga;
		
		System.out.println("Elegir opcion de carga de datos");
		System.out.println("1. Para carga automatica");
		System.out.println("2. Para carga manual");
		carga= sc.nextLine();
		if(carga == "1") {
			return true;
		}
		return false;
		
	}
	
	public PlanHotel enviarMailDeReservaHotel(int eleccion) {
		return  this.getPlanHotel().get(eleccion).getCopia();
	} 
	
	public PlanVuelo enviarMailDeReservaViaje(int eleccion) {
		return  this.getVuelosDisponibles().get(eleccion).getCopia();
	} 
	
	public void cargaAutomatica(CargarPlanAutomatico cargaAutomatico, Usuario u) {
		cargaAutomatico.cargar(u);		
	}
	
	public void comprarEstadiaHotel() {
		Scanner sc= new Scanner(System.in);
		
		int i=0;
		for(PlanHotel h: this.getPlanHotel()) {
			System.out.println("Numero de hotel " + i);
			h.toString();
			i= i+1;
		}
		
		//EL USUARIO ELIGE
		System.out.println("Ingrese el numero de Hotel donde quiere comprar una estadia");
		int eleccion= sc.nextInt();
		System.out.println("Ingrese su dni ");
		int dni=sc.nextInt();
		
		if(esCargaAutomatica()){
			//MODELADO DEL ENVIO DE MAIL PUEDE SER ASI?
			PlanHotel nuevoPlanHotel= enviarMailDeReservaHotel(eleccion);
			CargarPlanAutomatico cargaAutomatico= new CargarPlanAutomaticoHotel(nuevoPlanHotel);
			Usuario u= this.getUsuario(dni);
			this.cargaAutomatica(cargaAutomatico, u);
			
		}
			CargaPlanManual cargaManual = new CargaPlanManualHotel();
			PlanHotel nuevoPlanHotel= this.getPlanHotel().get(eleccion).getCopia();
			Usuario u= this.getUsuario(dni);
			this.cargaManual(cargaManual, u);
		
	}
	
	//MOSTRAMOS VUELOS DISPONIBLES
	public void comprarViaje() {
		Scanner sc= new Scanner(System.in);
		
		int i=0;
		for(PlanVuelo v: this.getVuelosDisponibles()) {
			System.out.println("Numero de vuelo " + i);
			v.toString();
			i= i+1;
		}
		
		//EL USUARIO ELIGE
		System.out.println("Ingrese el numero de vuelo que quiere comprar de ida");
		int eleccionIda= sc.nextInt();
		System.out.println("Ingrese el numero de vuelo que quiere comprar de regreso");
		int eleccionRegreso= sc.nextInt();
		System.out.println("Ingrese su dni ");
		int dni=sc.nextInt();
		
		
		//REVISAR
		
		if(esCargaAutomatica()){
			PlanVuelo vueloIda= enviarMailDeReservaViaje(eleccionIda); // HACE UNA COPIA DEL PLAN DE VUELO QUE ELIGIO EL USUARIO
			PlanVuelo vueloRegreso= enviarMailDeReservaViaje(eleccionRegreso);
			CargarPlanAutomatico cargaAutomatico= new CargarPlanAutomaticoViaje(vueloIda, vueloRegreso);
			Usuario u= this.getUsuario(dni);
			this.cargaAutomatica(cargaAutomatico, u);
			
		}
		else {
			CargaPlanManual cargaManual = new CargaPlanManualViaje(this.servicioExterno);
			Usuario u= this.getUsuario(dni);
			this.cargaManual(cargaManual, u);
		}
	}

	public List<PlanVuelo> getVuelosDisponibles() {
		return Collections.unmodifiableList(this.planesVuelo);
	}

	public void setVueloDisponible(PlanVuelo planV) {
		this.planesVuelo.add(planV);
	}
	
	public void enviarNotificacionDeVuelo() {
		
		for(Usuario u : this.usuarios) {
			if(u.getAgendaDeViajes().viajaManiana()) {
				u.recibirNotificacionDeVuelo("Le recordamos que un vuelo programado dentro de 24 hs.");
			}
		}
	}

	public void suscribirseAPremium() {
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Ingrese su dni");
		int dni=sc.nextInt();
		Usuario u= this.getUsuario(dni);
		
		try{
			UsuarioPremium up= (UsuarioPremium) u;
			System.out.println("Ya es usuario premium.");
		} catch (Exception e) { 
			UsuarioPremium nuevoUsuario= new UsuarioPremium (u.getNombre(), u.getApellido(),u.getDni());
			this.usuarios.remove(u);
			this.setUsuario(nuevoUsuario);	
		}
	}
	
	public void verMapaPlanes() {
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Ingrese su dni ");
		int dni=sc.nextInt();
		Usuario u= this.getUsuario(dni);
		u.getAgendaDeViajes().getViajeActual().getMapa();
		//SE MUESTRA EL MAPA
	}
}
