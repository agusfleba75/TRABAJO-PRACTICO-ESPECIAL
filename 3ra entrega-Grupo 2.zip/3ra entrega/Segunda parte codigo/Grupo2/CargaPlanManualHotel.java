package Grupo2;

import java.util.Calendar;
import java.util.Scanner;

public class CargaPlanManualHotel extends CargaPlanManual {

	public CargaPlanManualHotel() {
		
	}
		
	public int pedirNroHabitacion() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Ingrese numero de habitacion");
		int nro= sc.nextInt();
		
		return nro;
	}
	
	public Hotel pedirDatosHotel() {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Ingrese nombre del Hotel");
		String nombre= sc.nextLine();
		
		System.out.println("Ingrese estrellas del Hotel");
		int estrellas= sc.nextInt();
		
		System.out.println("Ingrese ciudad del Hotel");
		String ciudad= sc.nextLine();
		
		return new Hotel(nombre,estrellas,ciudad);
		
	}
	
	public Calendar pedirFechaLlegada() {
		
		Scanner sc= new Scanner(System.in);
		Calendar fechaInicial = null;
		System.out.println("Ingrese anio fecha llegada del Hotel");
		int anio= sc.nextInt();
		System.out.println("Ingrese mes fecha llegada del Hotel");
		int mes= sc.nextInt();
		System.out.println("Ingrese dia fecha llegada del Hotel");
		int dia= sc.nextInt();
		
		fechaInicial.set(anio, mes, dia);
		
		return fechaInicial;
		
	}
	public Calendar pedirFechaSalida() {
		
		Scanner sc= new Scanner(System.in);
		Calendar fechaSalida = null;
		System.out.println("Ingrese anio fecha salida del Hotel");
		int anio= sc.nextInt();
		System.out.println("Ingrese mes fecha salida del Hotel");
		int mes= sc.nextInt();
		System.out.println("Ingrese dia fecha salida del Hotel");
		int dia= sc.nextInt();
		
		fechaSalida.set(anio, mes, dia);
		
		return fechaSalida;
	}
	
	@Override
	public boolean cargar(/*Plan plan,*/ Usuario u) {
		
		PlanHotel planH = null;//= (PlanVuelo) plan;
		planH.setNroHabitacion(this.pedirNroHabitacion());
		planH.setHotel(this.pedirDatosHotel());
		planH.setFechaLlegada(this.pedirFechaLlegada());
		planH.setFechaSalida(this.pedirFechaSalida());
		
		Viaje v= u.getAgendaDeViajes().buscarViaje(planH.getFechaLlegada(), planH.getHotel().getCiudad()/*, planH.getFechaSalida()*/);
		if(v!= null) {
			v.addPlanes(planH);
			return true;
		}
		
		
		return false;
	}
}
