package Grupo2;

import java.awt.Image;

public class Mapa {

	private Image referencias;
	
	public Mapa(Image referencias) {
		this.referencias=referencias;
	}

	public Image getReferencias() {
		return referencias;
	}

	public void setReferencias(Image referencias) {
		this.referencias = referencias;
	}
	
	public void verMapa() { // este metodo mostraria el mapa del correspondiente aeropuerto con sus respectivas referencias
		
	}

}
