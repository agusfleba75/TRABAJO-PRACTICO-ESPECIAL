package Grupo2;

import java.util.Scanner;

public class CargarPlanAutomaticoViaje extends CargarPlanAutomatico {
	
	private PlanVuelo regreso;
	
	public CargarPlanAutomaticoViaje(PlanVuelo ida, PlanVuelo regreso) {
		super(ida);
		this.regreso= regreso;
	}
	
	public String pedirDescripcion() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Ingrese descripcion para su viaje");
		String desc=  sc.nextLine();
		return desc;
	}
	
	public String pedirNombreViaje() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Ingrese nombre para su viaje");
		String nombre=  sc.nextLine();
		return nombre;
	}

	@Override
	public boolean cargar(Usuario u) {
		
		PlanVuelo vueloIda=(PlanVuelo) this.getNuevoPlan();
		
		Viaje viaje= new Viaje(this.pedirDescripcion(), this.pedirNombreViaje());
		
		if(viaje.sePuedeCargar(vueloIda, this.regreso)) {
			viaje.addPlanes(vueloIda);
			viaje.addPlanes(this.regreso);
			viaje.setUsuario(u);
			u.getAgendaDeViajes().addViajes(viaje);
			return true;
		}
		return false;
	}

}
