package Grupo2;

public class Hotel {
	
	private String nombre;
	private int estrellas;
	private String ciudad;
	
	public Hotel(String nombre, int estrellas, String ciudad) {
		this.nombre=nombre;
		this.setEstrellas(estrellas);
		this.ciudad= ciudad;
	}

	public String getNombre() {
		return nombre;
	}

	public int getEstrellas() {
		return estrellas;
	}

	public void setEstrellas(int estrellas) {
		this.estrellas = estrellas;
	}

	public String getCiudad() {
		return ciudad;
	}
	
	public String toString() {
		return ("Nombre de hotel " + this.getNombre() +
				" \nCantidad de estrellas " + this.getEstrellas() + 
				" \nCiudad " + this.getCiudad());
	}

}
