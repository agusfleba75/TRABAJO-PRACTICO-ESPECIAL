package Grupo2;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Agenda {
	
	private List<Viaje> viajes;

	public Agenda() {
		this.viajes=new ArrayList<Viaje>();
	}

	public List<Viaje> getViajesRealizados() {
		Calendar fechaActual= Calendar.getInstance();
		List<Viaje> viajesRealizados= new ArrayList<Viaje>();
		
		for(Viaje v: this.viajes) {
			if(v.getFechaSalida().compareTo(fechaActual) ==-1) {
				viajesRealizados.add(v);
			}
		}
		
		return Collections.unmodifiableList(viajesRealizados);
	}
	
	public String concatenar(List<Viaje> lista) {
		
		String retorno="";
		
		for(Viaje v: lista) {
			retorno= retorno + "Nombre: " + v.getNombre() + 
					"\n Ciudad destino: " + v.getCiudadDestino() +
					"\n Fecha inicio: " + v.getFechaSalida() 
		//	 Fecha fin:  NO LA MOSTRAMOS PORQUE ACORDAMOS QUE EL VIAJE PODIA SER SOLO DE IDA SIN NECESIDAD DE COMPRAR LA VUELTA
					+ "\n Descripcion " + v.getDescripcion();
		}
		
		return retorno;
		
	}
	
	public String toStringViajesRealizados() {
		List<Viaje> viajesRealizados= this.getViajesRealizados();
		return concatenar(viajesRealizados);		
	}
	
	public String toStringViajesFuturos() {
		List<Viaje> viajesFuturos= this.getViajesRealizados();
		return concatenar(viajesFuturos);		
	}
	
	public List<Viaje> getViajesFuturos() {
		Calendar fechaActual= Calendar.getInstance();
		List<Viaje> viajesFuturos= new ArrayList<Viaje>();
		
		for(Viaje v: this.viajes) {
			if(v.getFechaSalida().compareTo(fechaActual) == 1) {
				viajesFuturos.add(v);
			}
		}
		
		return Collections.unmodifiableList(viajesFuturos);
	}

	public void addViajes(Viaje viaje) {
		this.viajes.add(viaje);
	}
	
	public void ordenarViajes(Comparator<Viaje> comparadorPorViaje) {
		Collections.sort(this.viajes, comparadorPorViaje);
		
	}
	
	public List<Viaje> getViajes(){
		return Collections.unmodifiableList(this.viajes);
	}
	
	public Viaje buscarViaje(Calendar fechaLlegada, String ciudad/*, Calendar fechaSalida*/){
		
		
		for(Viaje v: this.getViajesFuturos()) {
			if((v.getFechaLlegada() == fechaLlegada) && (v.getCiudadDestino() == ciudad)) {
				return v;
			}
		}
		
		return null;
		
	}
	

}
