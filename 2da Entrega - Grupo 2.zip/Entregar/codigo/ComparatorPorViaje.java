package Grupo2;

import java.util.Calendar;
import java.util.Comparator;

public class ComparatorPorViaje implements Comparator<Viaje>{


	@Override
	public int compare(Viaje o1, Viaje o2) {
		Calendar e1= o1.getFechaSalida();
		Calendar e2= o2.getFechaSalida();
		
		if(e1.get(Calendar.YEAR) < e2.get(Calendar.YEAR)) {
			return -1;
		}
		
		if(e1.get(Calendar.YEAR) > e2.get(Calendar.YEAR)) {
			return 1;
		}
		
		if(e1.get(Calendar.YEAR) == e2.get(Calendar.YEAR)) {
			if(e1.get(Calendar.MONTH) < e2.get(Calendar.MONTH)) {
				return -1;
			}
			if(e1.get(Calendar.MONTH) > e2.get(Calendar.MONTH)) {
					return 1;
			}
			if(e1.get(Calendar.MONTH) == e2.get(Calendar.MONTH)) {
				if(e1.get(Calendar.DATE) < e2.get(Calendar.DATE)) {
					return -1;
				}
				if(e1.get(Calendar.DATE) > e2.get(Calendar.DATE)) {
					return 1;
				}
				
				if(e1.get(Calendar.DATE) == e2.get(Calendar.DATE)) {
					return 0;
				}
				}
								
		}
		return 0;

	}
}


