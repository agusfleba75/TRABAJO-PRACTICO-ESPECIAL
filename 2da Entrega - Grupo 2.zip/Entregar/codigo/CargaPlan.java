package Grupo2;

public abstract class CargaPlan {
	
	public abstract boolean cargar(Usuario u); 
}
