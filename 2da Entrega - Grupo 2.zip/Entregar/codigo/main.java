package Grupo2;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.List;

public class main {

	public static void main(String[] args) {
		
		//SETEAMOS ESCALAS
		Calendar horaInicio0 = Calendar.getInstance();
		horaInicio0.set(2010, 0, 0, 15, 0);
		
		Escala e0= new Escala(horaInicio0, null, "0");
		Calendar horaInicio = Calendar.getInstance();
		horaInicio.set(2009, 0, 1, 14, 0);
		
		Calendar horaFin= Calendar.getInstance();
		horaFin.set(2009, 0, 1, 16, 0);
		
		Escala e= new Escala(null, null, "1");
		e.setFechaInicio(horaInicio);
		e.setFechaFin(horaFin);
		Calendar horaInicio1= Calendar.getInstance();
		horaInicio1.set(2011, 0, 2, 6, 0);
		
		Escala e1= new Escala(horaInicio1, null, "2");
		e1.setFechaInicio(horaInicio);
//		e1.setFechaFin(horaFin);
		
		//VEMOS EL TIEMPO ENTRE ESCALAS
		System.out.println(e.getTiempo());
		
		
		//CREAMOS VIAJES
		Viaje viaje0= new Viaje(null, "viaje0");
		Viaje viaje1= new Viaje(null, "viaje1");
//		
		Calendar fechaInicial= Calendar.getInstance();
		fechaInicial.set(2020, 1, 1);
		Calendar fechaFinal= Calendar.getInstance();
		fechaFinal.set(2020, 2, 1);
		
		
		//CREAMOS PLANES
		Plan p0= new Plan (null, null, fechaInicial, fechaFinal, 1);
		
		fechaInicial= Calendar.getInstance();
		fechaInicial.set(2019,3 , 1);
		fechaFinal= Calendar.getInstance();
		fechaFinal.set(2019, 3, 10);
		Plan p1= new Plan (null, null, fechaInicial, fechaFinal, 0);
		
		fechaInicial= Calendar.getInstance();
		fechaInicial.set(2021,3 , 1);
		fechaFinal= Calendar.getInstance();
		fechaFinal.set(2021, 3, 10);
		Plan p3= new Plan (null, null,  fechaInicial, fechaFinal, 0);
	
		//AGREGAMOS PLANES AL VIAJE
		viaje1.addPlanes(p0);
		viaje1.addPlanes(p1);
		
		viaje0.addPlanes(p3);
		
		
		List<Plan> planes = new ArrayList<Plan>();
		planes= viaje1.getPlanes();
		
/*		for(Plan p: planes) {
			System.out.println("nombre " + p.getCodigoReserva());
		}
	*/	
		
		//ORDENAMOS LOS PLANES POR FECHA
		ComparatorPorPlan comparadorPorPlan= new ComparatorPorPlan();
		viaje1.ordenarPlanes(comparadorPorPlan);
		
/*		System.out.println(" ");
		System.out.println("ordenado ");
		System.out.println(" ");
	*/	
		planes= viaje1.getPlanes();
/*		for(Plan p: planes) {
			System.out.println("nombre " + p.getCodigoReserva());
		}
	*/	
		System.out.println(" ");
		
		
		//CREAMOS LA AGENDA
		Agenda agenda= new Agenda();
		//LE CARGAMOS VIAJES
		agenda.addViajes(viaje0);
		agenda.addViajes(viaje1);
		
		
		List<Viaje> viajes= agenda.getViajes();
		
		for(Viaje p: viajes) {
			System.out.println("nombre " + p.getNombre());
		}
		
		System.out.println(" ");
		System.out.println("ordenado ");
		System.out.println(" ");
		ComparatorPorViaje comparadorPorViaje= new ComparatorPorViaje();
		
		//ORDENAMOS LOS VIAJES
		agenda.ordenarViajes(comparadorPorViaje);
		viajes= agenda.getViajes();
		
		for(Viaje p: viajes) {
			System.out.println("nombre " + p.getNombre());
		}
		
		//VEMOS VIAJES REALIZADOS
		viajes= agenda.getViajesRealizados();
		
		System.out.println(" ");
		System.out.println("viajes realizados ");
		System.out.println(" ");
		
		for(Viaje p: viajes) {
			System.out.println("nombre " + p.getNombre());
		}
		
		//VEMOS VIAJES FUTUROS
		viajes= agenda.getViajesFuturos();
		
		System.out.println(" ");
		System.out.println("viajes futuros ");
		System.out.println(" ");
		
		for(Viaje p: viajes) {
			System.out.println("nombre " + p.getNombre());
		}
		
		//CREAMOS UN VUELO
		Vuelo vuelo0= new Vuelo("Aerolineas Argentinas" , "Turista");
		
		//CON SUS ESCALAS
		fechaInicial= Calendar.getInstance();
		fechaInicial.set(2020, 3 , 1, 13, 0);
		fechaFinal= Calendar.getInstance();
		fechaFinal.set(2020, 3, 1, 16, 0);
		e0= new Escala(fechaInicial, fechaFinal, "0");		
	
		fechaInicial= Calendar.getInstance();
		fechaInicial.set(2020, 3 , 2, 16, 0);
		fechaFinal= Calendar.getInstance();
		fechaFinal.set(2020, 3, 2, 20, 0);
		Escala e2= new Escala(fechaInicial, fechaFinal, "2");
		
		Calendar fechaViajeInicial= Calendar.getInstance();
		fechaViajeInicial.set(2020, 3, 1);
		Calendar fechaViajeFinal= Calendar.getInstance();
		fechaViajeFinal.set(2020, 3, 2);
			
		//CREAMOS UN PLAN DE VUELO
		PlanVuelo planVuelo= new PlanVuelo("EZEIZA(ARG)", "CHIN(TAIWAN)", fechaViajeInicial, fechaViajeFinal, 123, vuelo0, 0);
		planVuelo.addEscala(e0);
		planVuelo.addEscala(e2);
		
		//VEMOS EL PLAN DE VUELO
		System.out.println(planVuelo.toString());		
		
	}

}
