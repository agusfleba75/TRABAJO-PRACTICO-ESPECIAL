package Grupo2;

import java.util.Collections;
import java.util.List;

public class Usuario {
	
	private String nombre;
	private String apellido;
	private int dni;
	private Agenda agendaDeViajes;

	public Usuario(String nombre, String apellido, int dni) {
		this.nombre=nombre;
		this.apellido=apellido;
		this.dni=dni;
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public int getDni() {
		return dni;
	}

	public Agenda getAgendaDeViajes() {
		return agendaDeViajes;
	}

	public void setAgendaDeViajes(Agenda agendaDeViajes) {
		this.agendaDeViajes = agendaDeViajes;
	}
	
	public boolean equals(Object o1) {
		try{
			Usuario u = (Usuario)o1;
			return (this.getDni() == (u.getDni()));
		} catch (Exception e) { 
			return false;
		}
		
	}
	
}
