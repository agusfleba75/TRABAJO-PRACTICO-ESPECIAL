package Grupo2;

import java.util.Calendar;

public class Plan {
	
	private Calendar fechaInicial;
	private Calendar fechaLlegada;
	private int codigoReserva;
	private String origen;
	private String destino;

	
	public Plan(String origen, String destino, Calendar fechaInicial, Calendar fechaLlegada, int codigoReserva) {
		this.fechaInicial=fechaInicial;
		this.fechaLlegada=fechaLlegada;
		this.codigoReserva=codigoReserva;
		this.destino= destino;
		this.origen= origen;
	}
	
	public Calendar getFechaInicial() {
		return fechaInicial;
	}
	
	public void setFechaInicial(Calendar fechaInicial) {
		this.fechaInicial = fechaInicial;
	}
	
	public Calendar getFechaLlegada() {
		return fechaLlegada;
	}
	
	public void setFechaLlegada(Calendar fechaLlegada) {
		this.fechaLlegada = fechaLlegada;
	}
	
	public int getCodigoReserva() {
		return codigoReserva;
	}
	
	public void setCodigoReserva(int codigoReserva) {
		this.codigoReserva = codigoReserva;
	}
	
	public boolean equals(Object o1) {
		try{
			Plan p = (Plan)o1;
			return (this.getCodigoReserva() == (p.getCodigoReserva()));
		} catch (Exception e) { 
			return false;
		}
		
	}

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}
	
	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

}
