package Grupo2;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class OpcionesUsuario {
	
	private FlightStats servicioExterno;
	private List<Usuario> usuarios;
	private List<PlanVuelo> planesVuelo;
	private List<PlanHotel> planHotel;

	public Sistema(FlightStats servicioExterno) {
		this.usuarios= new ArrayList<Usuario>();
		this.planesVuelo=new ArrayList<PlanVuelo>();
		this.planHotel= new ArrayList<PlanHotel>();
		this.servicioExterno=servicioExterno;
	}
	
	public void cargaManual(CargaPlanManual cargaManual, Usuario u) {
		cargaManual.cargar(u);
	}
	
	public void addPlanHotel(PlanHotel p) {
		this.planHotel.add(p);
	}
	
	public List<PlanHotel> getPlanHotel(){
		return Collections.unmodifiableList(this.planHotel);
	}
	
	public List<Usuario> getUsuarios() {
		return Collections.unmodifiableList(this.usuarios);
	}

	public void setUsuario(Usuario usuario) {
		this.usuarios.add(usuario);
	}
	
	public Usuario getUsuario(int dni) {
		
		for(Usuario u: this.usuarios) {
			if(u.getDni() ==(dni)) {
				return u;
			}
		}
		
		return null;
	}
	
	public boolean esCargaAutomatica() {
		Scanner sc= new Scanner(System.in);
		String carga;
		
		System.out.println("Elegir opcion de carga de datos");
		System.out.println("1. Para carga automatica");
		System.out.println("2. Para carga manual");
		carga= sc.nextLine();
		if(carga == "1") {
			return true;
		}
		return false;
		
	}
	
	public PlanHotel enviarMailDeReservaHotel(int eleccion) {
		return  this.getPlanHotel().get(eleccion).getCopia();
	} 
	
	public PlanVuelo enviarMailDeReservaViaje(int eleccion) {
		return  this.getVuelosDisponibles().get(eleccion).getCopia();
	} 
	
	public void cargaAutomatica(CargarPlanAutomatico cargaAutomatico, Usuario u) {
		cargaAutomatico.cargar(u);
		
		
	}
	
	public void comprarEstadiaHotel() {
		Scanner sc= new Scanner(System.in);
		
		int i=0;
		for(PlanHotel h: this.getPlanHotel()) {
			System.out.println("Numero de hotel " + i);
			h.toString();
			i= i+1;
		}
		
		//EL USUARIO ELIGE
		System.out.println("Ingrese el numero de Hotel donde quiere comprar una estadia");
		int eleccion= sc.nextInt();
		System.out.println("Ingrese su dni ");
		int dni=sc.nextInt();
		
		if(esCargaAutomatica()){
			//MODELADO DEL ENVIO DE MAIL PUEDE SER ASI?
			PlanHotel nuevoPlanHotel= enviarMailDeReservaHotel(eleccion);
			CargarPlanAutomatico cargaAutomatico= new CargarPlanAutomaticoHotel(nuevoPlanHotel);
			Usuario u= this.getUsuario(dni);
			this.cargaAutomatica(cargaAutomatico, u);
			
		}
		else {
			CargaPlanManual cargaManual = new CargaPlanManualHotel();
			PlanHotel nuevoPlanHotel= this.getPlanHotel().get(eleccion).getCopia();
			Usuario u= this.getUsuario(dni);
			this.cargaManual(cargaManual, u);
		}
	}
	
	//MOSTRAMOS VUELOS DISPONIBLES
	public void comprarViaje() {
		Scanner sc= new Scanner(System.in);
		
		int i=0;
		for(PlanVuelo v: this.getVuelosDisponibles()) {
			System.out.println("Numero de vuelo " + i);
			v.toString();
			i= i+1;
		}
		
		//EL USUARIO ELIGE
		System.out.println("Ingrese el numero de vuelo que quiere comprar");
		int eleccion= sc.nextInt();
		System.out.println("Ingrese su dni ");
		int dni=sc.nextInt();
		
		if(esCargaAutomatica()){
			PlanVuelo nuevoPlanVuelo= enviarMailDeReservaViaje(eleccion);
			CargarPlanAutomatico cargaAutomatico= new CargarPlanAutomaticoViaje(nuevoPlanVuelo);
			Usuario u= this.getUsuario(dni);
			this.cargaAutomatica(cargaAutomatico, u);
			
		}
		else {
			CargaPlanManual cargaManual = new CargaPlanManualViaje(this.servicioExterno);
			Usuario u= this.getUsuario(dni);
			this.cargaManual(cargaManual, u);
		}
	}

	public List<PlanVuelo> getVuelosDisponibles() {
		return Collections.unmodifiableList(this.planesVuelo);
	}

	public void setViajesDisponibles(PlanVuelo planV) {
		this.planesVuelo.add(planV);
	}

}
