package Grupo2;

public abstract class CargaPlanManual extends CargaPlan {
	

	@Override
	public abstract boolean cargar(Usuario u);

	
}
