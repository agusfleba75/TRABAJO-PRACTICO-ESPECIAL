package Grupo2;

public class Vuelo {
	
	private String compania;
	private String clase;
	
	public Vuelo(String compania, String clase) {
		this.compania= compania;
		this.clase= clase;
	}

	public String getCompania() {
		return compania;
	}

	public void setCompania(String compania) {
		this.compania = compania;
	}

	public String getClase() {
		return clase;
	}

	public void setClase(String clase) {
		this.clase = clase;
	}

}
