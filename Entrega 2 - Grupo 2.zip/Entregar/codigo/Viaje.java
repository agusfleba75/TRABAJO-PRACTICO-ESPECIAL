package Grupo2;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Viaje {
	
	private String descripcion;
	private List<Plan> planes;
	private String nombre;
	private Usuario usuario;
	
	
	public Viaje(String descripcion, String nombre) {
		this.descripcion= descripcion;
		this.nombre= nombre;
		this.planes=new ArrayList<Plan>();
	
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public List<Plan> getPlanes() {
		return Collections.unmodifiableList(planes);
	}

	public void addPlanes(Plan plan) { 
		this.planes.add(plan);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public Calendar getFechaSalida() {
		return this.getPlanes().get(0).getFechaInicial();
	}
	
	public Calendar getFechaLlegada() {
		return this.getPlanes().get(0).getFechaLlegada();
	}
	
	public String getCiudadDestino() {
		return this.getPlanes().get(0).getDestino();
	}
	
	public void ordenarPlanes(Comparator<Plan> comparadorPorPlan) {
		Collections.sort(this.planes, comparadorPorPlan);

	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
}
