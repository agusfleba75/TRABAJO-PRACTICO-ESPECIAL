package Grupo2;

import java.util.Scanner;

public class CargarPlanAutomaticoViaje extends CargarPlanAutomatico {
	
	public CargarPlanAutomaticoViaje(PlanVuelo nuevoPlanVuelo) {
		super(nuevoPlanVuelo);
	}
	
	public String pedirDescripcion() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Ingrese descripcion para su viaje");
		String desc=  sc.nextLine();
		return desc;
	}
	
	public String pedirNombreViaje() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Ingrese nombre para su viaje");
		String nombre=  sc.nextLine();
		return nombre;
	}

	@Override
	public boolean cargar(Usuario u) {
		
		PlanVuelo v=(PlanVuelo) this.getNuevoPlan();
		
		Viaje viaje= new Viaje(this.pedirDescripcion() , this.pedirNombreViaje());
		viaje.addPlanes(v);
		viaje.setUsuario(u);
		u.getAgendaDeViajes().addViajes(viaje);
		return true;
	}

}
