package Grupo2;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.List;

public class main {

	public static void main(String[] args) {
		
		
		Calendar horaInicio0 = Calendar.getInstance();
		horaInicio0.set(2010, 0, 0, 15, 0);
		
//		Calendar horaFin0 = new GregorianCalendar(2010, Calendar.FEBRUARY, 22, 23, 11, 44);
		Escala e0= new Escala(horaInicio0, null, "0");
		Calendar horaInicio = Calendar.getInstance();
		horaInicio.set(2009, 0, 1, 14, 0);
		
		Calendar horaFin= Calendar.getInstance();
		horaFin.set(2009, 0, 1, 16, 0);
		
//		Calendar horaFin = new GregorianCalendar(2010, Calendar.FEBRUARY, 22, 23, 11, 44);
		Escala e= new Escala(null, null, "1");
		e.setFechaInicio(horaInicio);
		e.setFechaFin(horaFin);
		Calendar horaInicio1= Calendar.getInstance();
		horaInicio1.set(2011, 0, 2, 6, 0);
		
//		Calendar horaFin1 = new GregorianCalendar(2010, Calendar.FEBRUARY, 22, 23, 11, 44);
		Escala e1= new Escala(horaInicio1, null, "2");
		e1.setFechaInicio(horaInicio);
//		e1.setFechaFin(horaFin);
		
		System.out.println(e.getTiempo());
		
		Viaje viaje0= new Viaje(null, "viaje0");
		Viaje viaje1= new Viaje(null, "viaje1");
//		
		Calendar fechaInicial= Calendar.getInstance();
		fechaInicial.set(2020, 1, 1);
		Calendar fechaFinal= Calendar.getInstance();
		fechaFinal.set(2020, 2, 1);
		
		Plan p0= new Plan (null, fechaInicial, fechaFinal, 1);
		
		fechaInicial= Calendar.getInstance();
		fechaInicial.set(2019,3 , 1);
		fechaFinal= Calendar.getInstance();
		fechaFinal.set(2019, 3, 10);
		Plan p1= new Plan (null, fechaInicial, fechaFinal, 0);
		
		fechaInicial= Calendar.getInstance();
		fechaInicial.set(2021,3 , 1);
		fechaFinal= Calendar.getInstance();
		fechaFinal.set(2021, 3, 10);
		Plan p3= new Plan (null, fechaInicial, fechaFinal, 0);
	
		viaje1.addPlanes(p0);
		viaje1.addPlanes(p1);
		
		viaje0.addPlanes(p3);
		
		List<Plan> planes = new ArrayList<Plan>();
		planes= viaje1.getPlanes();
		
/*		for(Plan p: planes) {
			System.out.println("nombre " + p.getCodigoReserva());
		}
	*/	
		ComparatorPorPlan comparadorPorPlan= new ComparatorPorPlan();
		viaje1.ordenarPlanes(comparadorPorPlan);
		
/*		System.out.println(" ");
		System.out.println("ordenado ");
		System.out.println(" ");
	*/	
		planes= viaje1.getPlanes();
/*		for(Plan p: planes) {
			System.out.println("nombre " + p.getCodigoReserva());
		}
	*/	
		System.out.println(" ");
		
		Agenda agenda= new Agenda();
		
		agenda.addViajes(viaje0);
		agenda.addViajes(viaje1);
		
		
		List<Viaje> viajes= agenda.getViajes();
		
		for(Viaje p: viajes) {
			System.out.println("nombre " + p.getNombre());
		}
		
		System.out.println(" ");
		System.out.println("ordenado ");
		System.out.println(" ");
		ComparatorPorViaje comparadorPorViaje= new ComparatorPorViaje();
		
		agenda.ordenarViajes(comparadorPorViaje);
		viajes= agenda.getViajes();
		
		for(Viaje p: viajes) {
			System.out.println("nombre " + p.getNombre());
		}
		
		viajes= agenda.getViajesRealizados();
		
		System.out.println(" ");
		System.out.println("viajes realizados ");
		System.out.println(" ");
		
		for(Viaje p: viajes) {
			System.out.println("nombre " + p.getNombre());
		}
		
		viajes= agenda.getViajesFuturos();
		
		System.out.println(" ");
		System.out.println("viajes futuros ");
		System.out.println(" ");
		
		for(Viaje p: viajes) {
			System.out.println("nombre " + p.getNombre());
		}
		
		Vuelo vuelo0= new Vuelo("Aerolineas Argentinas" , "Turista");
		
		fechaInicial= Calendar.getInstance();
		fechaInicial.set(2020, 3 , 1, 13, 0);
		fechaFinal= Calendar.getInstance();
		fechaFinal.set(2020, 3, 1, 16, 0);
		e0= new Escala(fechaInicial, fechaFinal, "0");		
	
		fechaInicial= Calendar.getInstance();
		fechaInicial.set(2020, 3 , 2, 16, 0);
		fechaFinal= Calendar.getInstance();
		fechaFinal.set(2020, 3, 2, 20, 0);
		Escala e2= new Escala(fechaInicial, fechaFinal, "2");
		
		Calendar fechaViajeInicial= Calendar.getInstance();
		fechaViajeInicial.set(2020, 3, 1);
		Calendar fechaViajeFinal= Calendar.getInstance();
		fechaViajeFinal.set(2020, 3, 2);
			
		
		PlanVuelo planVuelo= new PlanVuelo("EZEIZA(ARG)", "CHIN(TAIWAN)", fechaViajeInicial, fechaViajeFinal, 123, vuelo0, 0);
		planVuelo.addEscala(e0);
		planVuelo.addEscala(e2);
		
		
		System.out.println(planVuelo.toString());		
		
	}

}
