package Grupo2;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class PlanVuelo extends Plan {
	
	private Vuelo vuelo;
	private int nroVuelo;
	private List<Escala> escalas;
	
	public PlanVuelo(String origen, String destino, Calendar fechaInicial, Calendar fechaFinal, int codigoReserva, Vuelo vuelo, 
			int nroVuelo ) {
		super(origen, destino, fechaInicial, fechaFinal, codigoReserva/*, "planVuelo"*/);
		this.vuelo=vuelo;
		this.nroVuelo= nroVuelo;
		this.escalas= new ArrayList<Escala>();
	}

	public Vuelo getVuelo() {
		return vuelo;
	}

	public void setVuelo(Vuelo vuelo) {
		this.vuelo = vuelo;
	}

	public int getNroVuelo() {
		return nroVuelo;
	}

	public void setNroVuelo(int nroVuelo) {
		this.nroVuelo = nroVuelo;
	}

	public List<Escala> getEscalas() {
		return Collections.unmodifiableList(escalas);
	}

	public void addEscala(Escala escala) {
		this.escalas.add(escala);
	}
	
	public String toStringEscalas() {
		String retorno="";
		for(Escala e: this.escalas) {
			retorno= retorno + " aeropuerto " + e.getAeropuerto()+ " tiempo " +  e.getTiempo() +  " \n";
		}
		
		return retorno;
	}
	
	public String toString() {
		return ("Numero de vuelo " + this.getNroVuelo() +
				" \nCompania " + this.vuelo.getCompania() + 
				" \nFecha salida " + super.getFechaInicial().getTime() + 
				" \nFecha llegada " + super.getFechaLlegada().getTime() + 
				" \nAeropuerto salida " + super.getOrigen() +
				" \nAeropuerto llegada " + this.getDestino() + 
				" \nCodigo de reserva " + this.getCodigoReserva() +
				" \nEscalas: " + "  \n" + this.toStringEscalas());
	}
	
	public PlanVuelo getCopia() {
		PlanVuelo retorno= new PlanVuelo(this.getOrigen(),this.getDestino(), super.getFechaInicial(), super.getFechaLlegada(), 
				this.getCodigoReserva(), this.getVuelo(), this.getNroVuelo());
		
		for(Escala e: this.escalas) {
			retorno.addEscala(e);
		}
		
		return retorno;
	}
}
