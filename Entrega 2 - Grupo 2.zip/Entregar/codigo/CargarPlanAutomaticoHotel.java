package Grupo2;

public class CargarPlanAutomaticoHotel extends CargarPlanAutomatico {
	
	public CargarPlanAutomaticoHotel(PlanHotel nuevoPlanHotel) {
		super(nuevoPlanHotel);
	}

	@Override
	public boolean cargar(Usuario u) {
		
		PlanHotel p=(PlanHotel) this.getNuevoPlan();
		
		Viaje v= u.getAgendaDeViajes().buscarViaje(p.getFechaLlegada(), p.getHotel().getCiudad()/*, planH.getFechaSalida()*/);
		if(v!= null) {
			v.addPlanes(p);
			return true;
		}
		
		
		return false;
	}

}
